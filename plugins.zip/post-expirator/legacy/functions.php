<?php

/**
 * @deprecated 3.1.4
 */

defined('ABSPATH') or die('Direct access not allowed.');

