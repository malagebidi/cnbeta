<?php

namespace PublishPress\Future\Modules\Expirator\Exceptions;

use PublishPress\Future\Framework\BaseException;

defined('ABSPATH') or die('Direct access not allowed.');

class UndefinedActionException extends BaseException
{

}
