<?php
/**
 * Copyright (c) 2022. PublishPress, All rights reserved.
 */

namespace PublishPress\Future\Modules\Expirator;

defined('ABSPATH') or die('Direct access not allowed.');

abstract class CapabilitiesAbstract
{
    const EXPIRE_POST = 'publishpress_future_expire_post';
}
