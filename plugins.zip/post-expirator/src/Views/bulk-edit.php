<?php

defined('ABSPATH') or die('Direct access not allowed.');
?>

<div style="clear:both"></div>
<fieldset class="inline-edit-col-left post-expirator-quickedit">
    <div class="inline-edit-col">
        <div class="inline-edit-group">
            <div id="publishpress-future-bulk-edit"></div>
        </div>
    </div>
</fieldset>
