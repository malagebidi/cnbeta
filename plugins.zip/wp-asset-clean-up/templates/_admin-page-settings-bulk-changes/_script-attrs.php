<?php
/*
 * No direct access to this file
 */
if (! isset($data)) {
	exit;
}
?>
<p>This is the list of all the JavaScript files (<code>&lt;script&gt;</code> tags) that have "async" and "defer" attributes applied site-wide (everywhere). This feature is available only in the<img style="opacity: 0.6;" width="20" height="20" src="<?php echo esc_url(WPACU_PLUGIN_URL); ?>/assets/icons/icon-lock.svg" valign="top" alt="" /> <a href="<?php echo apply_filters('wpacu_go_pro_affiliate_link', WPACU_PLUGIN_GO_PRO_URL.'?utm_source=plugin_bulk_changes&utm_medium=script_attrs'); ?>"> Pro version</a>.</p>