<?php
/**
 * Silence is golden.
 *
 * @package    nginx-helper
 */

// Silence.
