<?php
/**
* Plugin Name: Disable Trash
* Plugin URI: https://carlosmr.com
* Description: This plugin removes the trash functionality from WordPress so that any content is deleted permanently.
* Version: 1.0.4
* Author: Carlos Mart&iacute;nez Romero
* Author URI: https://carlosmr.com
* License: GPL+2
* Text Domain: disable-trash
* Domain Path: /languages
*/
// Starts the plugin
add_action( 'plugins_loaded', 'cmr_dtrash_execute' );
function cmr_dtrash_execute(){
	if ( !defined( 'EMPTY_TRASH_DAYS' ) ){
	  // Definition of value
	  define( 'EMPTY_TRASH_DAYS', 0 );
	}
	else{
	}
}